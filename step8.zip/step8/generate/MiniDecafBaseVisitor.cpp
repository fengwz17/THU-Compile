
// Generated from MiniDecaf.g4 by ANTLR 4.8


#include "MiniDecafBaseVisitor.h"


